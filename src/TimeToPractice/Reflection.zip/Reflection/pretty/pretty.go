package pretty

import (
	"fmt"
)

func Print(i interface{}) {
	fmt.Println("TODO: pretty-print the sun and planet data.")
}
