#include <sys/ioctl.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
                     #define O_o "sfX4.Fv8H!`uf"\
                "|~0y'vWtA@:LcO9d}y.!uL!Gd+ml(<+Ds!J"\
            "e.6!r!%l6G!n~^<i=%pEwL%P!'<!FQt%u 5toG57j/3"\
         "!:E%;!ea!!!WqE0z!f/y}!%!!Qi6!uzt!n}?]!bl!ak!SetR<"\
       "Zj$x!~V!n&g8!cK! KrgR'8@c]!%-q9V.3fa[E8X%dY'w!#H <P~6"\
      "?guhljL!^P% ?"                            "8!@dP,!!o+fb"\
     "!pv!;!Hm%Ro4"                                "n:}nkD!Q!kN"\
     "e:| 'b5sc!e"                                  /* nothing */
     #define mu(a)                                  a a a a a //-
     #define O_(Q_                                  ) "\033[" #Q_
     #define Q_(O)                                  mu(mu(mu(O)))
     #define Q/*--                                  ++--*/O9--||(
     #define main(                                  )main(){/**/\
     signal(13,1),                                  _();}f()//--+
     #define k( k)                                  getenv( "D"#k
 char*O0=O_o,OO,*Q1,O5[97];int*Q5,_Q=0,Q0=0,_O=0,_0=0,O=5,QQ,O6,Q6,O3
,Q4,O4=41088,O1=sizeof(O5),O7=234;long long __;_()Q_({)int*Q3,Q2,O2,OQ
,QO, O9=O,O8=!!/*OQ*/k(RAFT));long long Q8;char*Q9=O_(1A)O_(%dB)O_(%dC
)O_(34m)"\xe2%c%c\r\n"O_(0m)O_(%dA),*Q7;__+=(__*92+*O0-35-__)*(QO=Q_(!
!)(*O0-33)*!O9--),O0+=O1*QO,QO&&_(),Q Q4&&(O--,_(),O0+=194,O++,Q4--,_(
))),Q O=0,__=0,_(),O=3,_()),Q __&&(_O+=((OQ=__&15)<2)*12+!(QO=OQ&14^2)
*(4-_O)+(OQ==6)*(12-2*_O)+(OQ>6)*(9-(OQ-7)%3),_Q+=!QO*(_Q%QQ+(OQ&1)*O3
-_Q),_0+=!_0*!QO+(1-2*_0)*!(OQ^4),(OQ==5)&&(__>>=4,Q8=__,Q7 =O0,Q4=__&
15,O     =1,_()|++O&_    (),O0 =Q7,__=        Q8),     Q3 =(      Q2=(
_Q+=     (lrand48()        <O4*O1*9)          *O8+     (OQ>      5)*((
(2<(     _O%=8)%6)          -(_O%7<       2))*QQ+(     (_O      +7)%8<
3)-(     _O>4)))/            O3 )*      O6+Q5+(O2=     _Q      %QQ)/2,
*Q3=     *Q3 %O4+     O4     |(1<<     Q_("@CADBE"            "HI")[_Q
%O3/     QQ*2+_Q     %2]-     64)      *_0,sprintf           (O5,Q9,Q2
+=1,     O2 /2,*     Q3>>     8,*      Q3&85*3,Q2)           &&_0&&(Q1
=O5,     O =8,_()     ),     Q0+=(     O2>Q0)*_0*(            O2-Q0 ),
__+=     (OQ>12)*            (((__      +=!(OQ>9)*     (3      -__+(__
>>4)     )-3)<<4)+          OQ-3-__       ),usleep     (O4      *_0/(3
*O8+           1)),        O=3,_()))          ,!O9     --&&      read(
1 ,&           OO,1)>    0&&(O= (QO=OO        ==35     )*3+6      ,_()
,QO&&(OO=10,O=6,_(),1)||(O=4,_()),0)||close(dup2(3-dup2(1,dup(0)-3),1)
*0+2)*0||Q write(1,"> ",2),ioctl(Q0=0,TIOCGWINSZ,O5)^--O&(O3=(QQ=(O6=*
((short*)O5+1))*2)*4),Q6=-O1,Q5=calloc(3*O6,8),_()),Q (O=8,QO=!(O2=OO-
10)|!(Q2=OO-32)*(Q0+58>QQ)|(Q0+12>QQ))&&(Q1=O_(3B),_(),write(1,"> ",2)
),Q0+=!QO*!Q2*4-QO*Q0,O2*Q2&&(!Q0&&(memset(Q5,0,3*O3),Q0=4,Q1="\n\n\n"
O_(3A),_()),O=7,_Q=7*QQ+Q0+2,_O=_0=0,OO+=(OO>64 &OO<91)*32,O0=Q_(O_o)+
O7,_(),(*O0-OO)||(O=2,O0+='a',_( )))),Q *O0-OO)&&(*(O0+=O1)-33)&&(O=0,
_(),O=7,O0+=O1,_()),Q write(0,Q1,strlen(Q1))),Q OO=Q_(O_o)[Q6+=O1],(Q6
 %strlen(O_o)-O7)&&(O=6,_(),O=9,_()));Q_(})/*+++++ IOCCC 2015 +++++*/

main()
{
    puts("hello world!");
}
