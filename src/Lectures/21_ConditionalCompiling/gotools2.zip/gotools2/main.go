package main

func main() {
	helloFromOS()
}
