package main

import "fmt"

func helloFromOS() {
	fmt.Println("Hello from 32-bit Linux!")
}
