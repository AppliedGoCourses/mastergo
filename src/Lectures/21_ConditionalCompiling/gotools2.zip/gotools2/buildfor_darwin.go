package main

import "fmt"

func helloFromOS() {
	fmt.Println("Hello from macOS!")
}
