package main

import "fmt"

func helloFromOS() {
	fmt.Println("Hello from 64-bit Linux!")
}
